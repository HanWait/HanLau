//
//  AppDelegate.swift
//  HanLanS
//
//  Created by lee on 2018/6/13.
//  Copyright © 2018年 lee. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?


    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        self.window?.makeKeyAndVisible()
        
        let launchImageView = UIImageView.init(frame: CGRect.init(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height))
        launchImageView.image = UIImage.init(named: "launchScreen_bg")
        launchImageView.backgroundColor = UIColor.red
        self.window?.addSubview(launchImageView)
        self.window?.bringSubview(toFront: launchImageView)
        
        
        let img_b = UIImageView.init(frame: CGRect.init(x: 0, y: 0, width: UIScreen.main.bounds.size.width * 0.7, height: UIScreen.main.bounds.size.width * 0.7))
        img_b.center = CGPoint.init(x: (self.window?.center.x)!, y: UIScreen.main.bounds.size.height * 0.36)
        img_b.image = UIImage.init(named: "launchScreen_b")
        launchImageView.addSubview(img_b)
        self.addAnimation(view: img_b, isOrder: false)
        
        let img_c = UIImageView.init(frame: CGRect.init(x: 0, y: 0, width: UIScreen.main.bounds.size.width * 0.7, height: UIScreen.main.bounds.size.width * 0.7))
        img_c.center = CGPoint.init(x: (self.window?.center.x)!, y: UIScreen.main.bounds.size.height * 0.36)
        img_c.image = UIImage.init(named: "launchScreen_c")
        launchImageView.addSubview(img_c)
        self.addAnimation(view: img_c, isOrder: true)
        
        
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
            
            UIView.animate(withDuration: 0.5, animations: {
                
            }, completion: { (finished:Bool) in
                
                launchImageView.removeFromSuperview()
                // do something
  
                
            })
            
        }
        
        return true
    }

    func addAnimation(view:UIView,isOrder:Bool)
    {
        let animation = CABasicAnimation.init(keyPath: "transform.rotation.z")
        if isOrder {
            animation.fromValue = 0.0
            animation.toValue = Double.pi * 2
        }
        else
        {
            animation.fromValue = Double.pi * 2
            animation.toValue = 0.0
        }
        animation.duration = 4
        animation.autoreverses = false
        animation.fillMode = kCAFillModeForwards
        animation.repeatCount = 2
        view.layer.add(animation, forKey: nil)
    }
    func applicationWillResignActive(_ application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
    }

    func applicationDidEnterBackground(_ application: UIApplication) {
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    }

    func applicationWillEnterForeground(_ application: UIApplication) {
        // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
    }

    func applicationDidBecomeActive(_ application: UIApplication) {
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    }

    func applicationWillTerminate(_ application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    }


}

